package com.imeldaaudina.uts_21082010003

import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DetailActivity:AppCompatActivity(){
    private lateinit var binding:ActivityDetailBinding
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        binding=ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val dataHandphone=if(Build.VERSION.SDK_INT>=33){
            intent.getParcelableExtra<Wisata>("key_wisata",
                Wisata::class.java)
        }else{
            @Suppress("DEPRECATION")
            intent.getParcelableExtra<Wisata>("key_wisata")
        }
        val tvDetailName=binding.tvDetailName
        val tvDetailDescription=binding.tvDetailDescription
        val ivDetailPhoto=binding.ivDetailPhoto
        if(dataHandphone!=null){
            tvDetailName.text=dataHandphone.name
            tvDetailDescription.text=dataHandphone.description
            ivDetailPhoto.setImageResource(dataHandphone.photo)
        }
    }
}