package com.imeldaaudina.uts_21082010003

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var binding: DetailActivity2
    private val list = ArrayList<Wisata>()
    private lateinit var rvHandphone: RecyclerView

    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        binding=DetailActivity2().inflate(layoutInflater)
        setContentView(binding.root)
        rvHandphone=binding.rvHandphone
        rvHandphone.setHasFixedSize(true)
        list.addAll(getListWisata())
        showRecyclerList()
    }
    private fun getListWisata():ArrayList<Wisata>{
        val dataName=resources.getStringArray(R.array.data_name)
        val dataDescription=
            resources.getStringArray(R.array.data_description)
        val dataPhoto=resources.obtainTypedArray(R.array.data_photo)
        val listWisata=ArrayList<Wisata>()
        for(i in dataName.indices){
            val wisata=Wisata(dataName[i],dataDescription[i],
                dataPhoto.getResourceId(i,-1))
            listWisata.add(wisata)
        }
        return listWisata
    }
    private fun showRecyclerList(){
        rvHandphone.layoutManager= LinearLayoutManager(this)
        val listHandphoneAdapter=ListWisataAdapter(list)
        rvHandphone.adapter=listHandphoneAdapter
    }
}