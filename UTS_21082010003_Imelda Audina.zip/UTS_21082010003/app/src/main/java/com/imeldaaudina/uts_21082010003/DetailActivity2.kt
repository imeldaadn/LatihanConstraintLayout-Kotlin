package com.imeldaaudina.uts_21082010003

import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DetailActivity2:AppCompatActivity(){
    private lateinit var binding:ActivityDetailBinding
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        binding=ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val dataWisata=if(Build.VERSION.SDK_INT>=34){
            intent.getParcelableExtra<Wisata>("key_wisata",
                Wisata::class.java)
        }else{
            @Suppress("DEPRECATION")
            intent.getParcelableExtra<Wisata>("key_wisata")
        }
        val tvDetailName=binding.tvDetailName
        val tvDetailDescription=binding.tvDetailDescription
        val ivDetailPhoto=binding.ivDetailPhoto
        if(dataWisata!=null){
            tvDetailName.text=dataWisata.name
            tvDetailDescription.text=dataWisata.description
            ivDetailPhoto.setImageResource(dataWisata.photo)
        }
    }
}