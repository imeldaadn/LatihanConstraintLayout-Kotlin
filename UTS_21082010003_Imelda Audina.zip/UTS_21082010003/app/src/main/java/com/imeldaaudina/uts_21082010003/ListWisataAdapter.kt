package com.imeldaaudina.uts_21082010003

import android.content.ClipData.Item
import android.content.Intent
import android.view.ViewGroup
import android.view.inputmethod.InputBinding
import androidx.recyclerview.widget.RecyclerView

class ListWisataAdapter (private val listWisata: ArrayList<Wisata>) :
    RecyclerView.Adapter<ListWisataAdapter.ListViewHolder>() {
    inner class ListViewHolder (val binding: ItemRowWisataBinding) : RecyclerView.ViewHolder(binding.root){
        fun bind(wisata: Wisata) {
            binding.apply {
                imgItemPhoto.setImageResource(wisata.photo)
                tvItemName.text = wisata.name
                tvItemDescription.text = wisata.description
            }
        }
    }
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ListWisataAdapter.ListViewHolder {
        TODO("Not yet implemented")
    }

    override fun onBindViewHolder(holder:ListViewHolder,position:Int){
        val(name,description,photo)=listHandphone[position]
        holder.binding.apply{
            imgItemPhoto.setImageResource(photo)
            tvItemName.text = name
            tvItemDescription.text = description
            root.setOnClickListener{
                val intentDetail = Intent(root.context,
                    DetailActivity2::class.java)
                intentDetail.putExtra("key_wisata",listwisata[position])
                root.context.startActivity(intentDetail)
            }
        }
    }

    override fun getItemCount(): Int {
        TODO("Not yet implemented")
    }
}